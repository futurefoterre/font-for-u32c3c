#!/sbin/sh

FONT_FILE="SubsetCJK.otf"
FONT_ENTRY="    <family lang=\"zh-Hans\">\n        <font weight=\"400\" style=\"normal\">${FONT_FILE}<\/font>\n        <font weight=\"700\" style=\"normal\">${FONT_FILE}<\/font>\n    <\/family>"

ui_print "- 正在配置字体回退..."

mkdir -p "$MODPATH/system/etc"

for XML in /system/etc/fonts.xml /system/etc/font_fallback.xml; do
    BASENAME=$(basename "$XML")
    if [ -f "$XML" ]; then
        cp "$XML" "$MODPATH/system/etc/$BASENAME"
        if grep -q "$FONT_FILE" "$MODPATH/system/etc/$BASENAME"; then
            ui_print "- $BASENAME: 已包含此字体，跳过"
        else
            sed -i "s|<\/familyset>|${FONT_ENTRY}\n<\/familyset>|" "$MODPATH/system/etc/$BASENAME"
            ui_print "- $BASENAME: 已添加字体回退 ✓"
        fi
    else
        ui_print "- $BASENAME: 不存在，跳过"
    fi
done
